Everything in this Folder is used in creation of the willsonFinancial DB

1. create and populate db by running the script found in (CreatePopulateDB.py).
2. I noticed some of the reports were blank and then I realized the Clients and Transactions tables did not have the information I was looking to query
3. Run both update scripts [(ClientsUpdate.py), (TransactionUpdate.py) ] in order to have all reports return valid data.
4. run all four reports in whatever order you like [(AvgClientAssetsReport.py), (ClientsHighTransactionReport.py),(HighestTotalAssetsReports.py), (newClientsAddedReport.py)]. 

*Reminder*
I placed a standard user and password within each script. Please remember to update these values locally before running them on your machine.